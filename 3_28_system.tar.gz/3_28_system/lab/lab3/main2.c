#include "stdio.h"
struct pcb   /*进程控制块结构体*/
{char name[3];     /*进程标识符*/
 char number[3];   /*进程优先数*/
 char status[2];   /*进程状态:0-就绪*/
 struct pcb *next; /*指向后一进程的指针*/
 struct pcb *prior;/*指向前一进程的指针*/
 }stu;
struct pcb *fir;   /*进程链表的头指针*/
struct pcb *back;  /*进程链表的尾指针*/
void enter( ),delete( ),prin( );
char str[12][3]={"a","2","0","b","10","0","c","30","0","d","35","0"};

main( )
{
 fir=back=NULL; /*对进程链表的头尾指针赋初值*/
 enter(0);     /*对进程链表赋初值*/
 for(;;)
   {switch(menu( )){
		    case 1 : enter(1);  break; /*插入或初始化*/
		    case 2 : delete( ); break; /*删除*/
		    case 3 : prin( );   break; /*显示*/
		    case 4 : exit(0);
		   }
   }
}

/*主菜单*/
menu( )
{
char ch[2];
int n;
printf("\t就绪队列操作,请选择功能:\n");
printf("\t1.插入进程的信息\n");
printf("\t2.删除进程的信息\n");
printf("\t3.显示进程链表内容\n");
printf("\t4.退出\n");
do{
   printf("\n\t请按数字选择:");
   gets(ch);
   n=atoi(ch);
   }while(n<0 || n>4);
return(n);
}

void enter(int q)
{
int qq;
struct pcb *inf,*bc( );
if(q==1)
{
  inf=(struct pcb *)malloc(sizeof(stu)); /*开辟新结点*/
  if(!inf){
	   printf("\tuse up!\n");
	   return;
	   }
  inputs("\t请输入进程标识符(最多两位):",inf->name,2);
  inputs("\t请输入进程优先数(最多两位):",inf->number,2);
  inputs("\t请输入进程当前状态(一位):",inf->status,1);
  fir=bc(inf,fir); /*插入新结点*/
}
  else
    {for(qq=0;qq<4;qq++)     /*结点初始化*/
       {inf=(struct pcb *)malloc(sizeof(stu));
	 if(!inf){
	   printf("\tuse up!\n");
	   return;
	   }
	strcpy(inf->name,str[qq*3]);
	strcpy(inf->number,str[qq*3+1]);
	strcpy(inf->status,str[qq*3+2]);
	fir=bc(inf,fir);
       }
    }
}

inputs(sm,s,count)
char *sm,*s;
int count;
{
char q[3];
do{
printf(sm); /*打印提示信息*/
gets(q);
if(strlen(q)>count) printf("\t太长了!\n"); /*输入长度判断*/
}
while(strlen(q)>count);
strcpy(s,q);    /*把输入内容放入结构中*/
}

struct pcb *bc(i,st)
struct pcb *i;
struct pcb *st;
{
struct pcb *j,*k;
if(atoi(i->status)==0)  /*判断进程状态是否就绪*/
{
  if(back==NULL)     /*链表为空时的插入*/
  {
  i->next=NULL;
  i->prior=NULL;
  back=i;
  return(i);
 }
 j=st;          /*令J指向链表的头*/
 while(j)
 {if(strcmp(j->name,i->name)==0) /*进程标识符要唯一*/
    {printf("\n\t该进程已存在就绪队列中。\n\n");
    return(st);
    }
  j=j->next;
 }
 j=st;
 k=NULL;
 while(j){
 if(atoi(j->number)<atoi(i->number)) /*判断进程优先数,找到要插入的位置*/
  {
   k=j;
   j=j->next;
  }
  else
   {
     if(j->prior)          /*判断J是否为头指针*/
     {
     j->prior->next=i;     /*在链表的中间插入*/
     i->next=j;
     i->prior=j->prior;
     j->prior=i;
     return(st);
     }
     i->next=j;            /*在链表的头插入*/
     i->prior=NULL;
     j->prior=i;
     return(i);
   }
}
  k->next=i;          /*在链表的尾插入*/
  i->next=NULL;
  i->prior=k;
  back=i;
  return(st);
}
printf("\n\t该进程不是就绪状态,不能插入就绪队列中。\n\n");
return(st);
}

void delete( )
{
struct pcb *in;
char s[2];
printf("\t请输入进程标识符:");
gets(s);
in=fir;
while(in){
if(strcmp(s,in->name)==0)   break; /*寻找要删除的进程*/
  else  in=in->next;
}
if(in==NULL)
  printf("\t未找到此进程!\n");
if(in){            /*找到进程*/
  if(fir==in)     /*该进程为链表头时*/
    {
    fir=in->next;
    if(fir) fir->prior=NULL;  /*该链表删除进程结点后不为空*/
    else back=NULL;
    }
  else{
      in->prior->next=in->next;
      if(in!=back)            /*该进程不在链表尾*/
	in->next->prior=in->prior;
      else back=in->prior;
      }
      free(in);            /*释放进程空间*/
      }
}

void prin( )
{
struct pcb *j;
j=fir;
while(j){     /*显示所有进程的信息*/
printf("\t%s   ",j->name);
printf("\t%s   ",j->number);
printf("\t%s   ",j->status);
printf("\n");
j=j->next;
}
}

