#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>

char kid_char;
char parent_char;
pid_t kid_pid;
pid_t parent_pid;

void signal_handler1()// par to kid
{
    printf("signal from par to kid-> par`s char :%c and pid :",parent_char);
    printf("%d\n",getppid());
}
void signal_handler2() //kid to par
{
    printf("signal from kid to par-> kid`s char :%c and pid :%d\n",kid_char,kid_pid);
}

int main(int agc,char * agv[])
{
    pid_t pid;

    printf("please intput a chars for kid process\n");
    scanf("%c",&kid_char);
    getchar();
    printf("please intput a chars for parent process\n");
    scanf("%c",&parent_char);

    if(signal(SIGUSR1,signal_handler1)==SIG_ERR)
    {
        printf("signal:SIGUSR1 ERROR\n");
        exit(1);
    }

    if(signal(SIGUSR2,signal_handler2)==SIG_ERR)
    {
        printf("signal:SIGUSR2 ERROR\n");
        exit(1);
    }

    pid = fork();
    if(pid == 0)
    {
        kill(getppid(),SIGUSR2);
        //parent_pid = getppid();

        wait(NULL);
    } else
    {
        kill(pid,SIGUSR1);
        kid_pid= pid;
        wait(NULL);
    }

    return 0;
}
