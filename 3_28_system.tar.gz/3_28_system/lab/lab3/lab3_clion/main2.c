//
// Created by melt on 18-4-11.
//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main() {
    pid_t pid;
    pid_t pid2;
    int fds[2];
    char string_kid1[] = "child process 1 is sending a message!";
    char string_kid2[] = "child process 2 is sending a message!";
    char buf[100];
    if (pipe(fds) == 0) {
        pid = fork();
        if (pid == 0) {
            close(fds[0]);
            write(fds[1], string_kid1, strlen(string_kid1));
            sleep(2);
            exit(1);
        }
        pid2 = fork();
        if (pid2 == 0) {
            close(fds[0]);
            write(fds[1], string_kid2, strlen(string_kid2));
            exit(2);
        }
        else {
            wait(NULL);
            close(fds[1]);
            read(fds[0], buf,strlen(string_kid1));
            printf("%s\n",buf);
            read(fds[0],buf,strlen(string_kid2));
            printf("%s\n",buf);
        }

    }

    return 0;
}
