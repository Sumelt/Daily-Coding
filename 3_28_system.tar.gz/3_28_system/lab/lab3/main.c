#include <stdio.h>
#include<unistd.h>
/*
int main() {
   int p,i;
    p = fork();
    if(p==0)
        printf("this is son, the pid is %d\n",getpid());
    else if (p>0)
    {
        printf("this is father and the son pid is %d\n",p);
        printf("the father pid is %d\n",getpid());
    }
    printf("code end\n");
    return 0;
}*/

/*int main()
{
    int p1,p2,i;
    while((p1=fork())==-1);
    if(p1==0)
        for(i=0;i<500;i++)
            printf("child1_%d\n",i);
    else
    {
        while((p2=fork())==-1);
        if(p2==0)
            for(i=0; i<500;i++)
                printf("child2_%d\n",i);
        else
            for(i=0;i<500;i++)
                printf("father %d\n",i);
    }
    printf("\n");
    return 0;
}*/

int main()
{
    int p1,p2,i;
    while((p1=fork())==-1);
    if(p1==0)
        for(i=0;i<500;i++)
        {
            lockf(1,1,0);
            printf("child1_%d\n",i);
            lockf(1,0,0);
        }

    else
    {
        while((p2=fork())==-1);
        if(p2==0)
            for(i=0; i<500;i++)
            {
                lockf(1,1,0);
                printf("child2_%d\n",i);
                lockf(1,0,0);

            }
        else
            for(i=0;i<500;i++)
            {
                lockf(1,1,0);
                printf("father %d\n",i);
                lockf(1,0,0);
            }
    }
    printf("\n");
    return 0;
}
