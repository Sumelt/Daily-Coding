#include <stdio.h>
#include <stdlib.h>

typedef struct PCB *pcb;
pcb a[2];

pcb creath();
pcb input();

//pcb sort(pcb P);

void print(pcb P);

struct PCB{
    char name[3];
    int run_time;
    int priority;
    char state;
    pcb next;

};

int main() {

    pcb program;
    program = input();
    //program = sort(program);
    //print(program);
    return 0;
}

pcb creath()
{
    pcb p = (pcb)malloc(100*(sizeof(pcb)));
    p->state = 'R';
    p->next = NULL;
    return p;

}

pcb input()
{
    pcb P = NULL;
    pcb Q = NULL;
    pcb head,tail;
    head = P;
    tail = head;
    int i;
    for ( i = 0; i < 2; ++i) {

        printf("Please input P%d run_time and priority\n",i);
        if (i==0)
        {
            P = creath();
            head = P;
            tail = head;
            head->name[0] = 'P';
            head->name[1] = i+'0';
            head->name[2] = '\0';
            scanf("%d %d",&head->run_time,&head->priority);

        } else
        {
            Q = creath();
            tail->next = Q;
            tail = Q;
            tail->name[0] = 'P';
            tail->name[1] = i+'0';
            tail->name[2] = '\0';
            scanf("%d %d",&tail->run_time,&tail->priority);
        }
    }
    return head;
}

/*
pcb sort(pcb P)
{
    pcb i,j;
    pcb point = NULL;

    for (i = P;i->next!=NULL;i = i->next) {
        printf("test\n");
    }
    point = i;

    for (i = P;i->next!=NULL;i = i->next) {
        for (j = P;j!=point;j = j->next) {
            if(j->priority < j->next->priority)
            {
                if(j->next->next!=NULL)
                {
                    j->next = j->next->next;
                    j->next->next = j;
                } else
                {
                    j->next->next = j;
                    j->next = NULL;
                    point = j;
                }

            }
        }
        point = j;
    }
    return P;
}
*/


void print(pcb P)
{
    for (P;P!=NULL;P=P->next) {
        printf("%s %d %d\n",P->name,P->run_time,P->priority);
    }
}
