#include "stdio.h"
struct gdf   /*固定分区结构体*/
{char num[2];     /*区号*/
 char size[4];   /*大小*/
 char begin[4];   /*起址*/
 char flag[2];
 struct gdf *next; /*后指针*/
 struct gdf *prior;/*前指针*/
 }stu;
struct gdf *fir;   /*分区链表的头指针*/
struct gdf *back;  /*分区链表的尾指针*/
void enter( ),turn(),prin( );
char str[16][4]={"1","16","20","1","2","32","36","1","3","64","68","1","4","124","132","0"};

main( )
{
 fir=back=NULL; /*对分区链表的头尾指针赋初值*/
 enter();     /*对分区链表赋初值*/
 for(;;)
   {switch(menu( )){
		    case 1 : inputs();  break; /*输入作业大小并处理*/
		    case 2 : turn();    break; /*改变分配状态*/
		    case 3 : prin( );   break; /*显示*/
		    case 4 : exit(0);          /*退出*/
		   }
   }
}

/*主菜单*/
menu( )
{
char ch[2];
int n;
printf("\n\t固定分区操作,请选择功能:\n");
printf("\t1.输入作业的大小\n");
printf("\t2.改变分区的分配状态\n");
printf("\t3.显示分区链表内容\n");
printf("\t4.退出\n");
do{
   printf("\t请按数字选择:");
   gets(ch);
   n=atoi(ch);
   }while(n<0 || n>4);
return(n);
}

void enter()
{
int qq;
struct gdf *inf,*bc();
for(qq=0;qq<4;qq++)     /*结点初始化*/
  {inf=(struct gdf *)malloc(sizeof(stu)); /*开辟新结点空间*/
   if(!inf){
   printf("\tuse up!\n");
   return;
   }
strcpy(inf->num,str[qq*4]);
strcpy(inf->size,str[qq*4+1]);
strcpy(inf->begin,str[qq*4+2]);
strcpy(inf->flag,str[qq*4+3]);
fir=bc(inf,fir);
}
}

inputs()
{
char q[5];
struct gdf *inf;
inf=fir;
while(inf)                   /*寻找空闲分区*/
{if(atoi(inf->flag)==0)
   break;
 inf=inf->next;
}                           /*不存在空闲分区,返回*/
if(!inf)
  {printf("\t暂时没有空闲分区.\n");
  return;}
printf("\t输入作业大小(K):"); /*打印提示信息*/
gets(q);
inf=fir;
while(inf)                   /*寻找符合条件的空闲分区,找到则返回*/
{if((atoi(q)<atoi(inf->size)) && atoi(inf->flag)==0)
  {strcpy(inf->flag,"1");
   printf("\t作业已分配在%s区.\n",inf->num);
   return;
   }
inf=inf->next;
}
printf("\t空闲分区不够大,请选择另一个较小的作业.\n");
}

void turn()
{
char q[5],q1[5];
struct gdf *inf;
printf("\t输入分区(1-4):"); /*打印提示信息*/
gets(q);
printf("\t输入分配状态(0-1):");
gets(q1);
inf=fir;
while(inf)
{
if(atoi(inf->num)==atoi(q))   /*寻找符合条件分区*/
  {strcpy(inf->flag,q1);      /*改变分区状态*/
   printf("\t%s分区已成功改变分区状态.\n",inf->num);
   return;
   }
inf=inf->next;
}
printf("\t该分区不存在.\n");
return;
}

void prin( )     /*显示*/
{
struct gdf *j;
j=fir;
printf("\t区号   ");
printf("\t大小   ");
printf("\t起址   ");
printf("\t标志\n");
while(j){     /*显示固定分区的信息*/
printf("\t%s      ",j->num);
printf("\t%s   ",j->size);
printf("\t%s   ",j->begin);
printf("\t%s   ",j->flag);
printf("\n");
j=j->next;
}
}

struct gdf *bc(i,st)
struct gdf *i;
struct gdf *st;
{
  struct gdf *k;
  if(back==NULL) {
  i->next=NULL;
  i->prior=NULL;
  back=i;
  return(i);
}
 k=back;
 k->next=i;
 i->next=NULL;
 i->prior=k;
 back=i;
 return(st);
}

