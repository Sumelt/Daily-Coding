#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>

#define MAXSIZE 4096
int parse (char *, char**);
void mydir(char** p);
void mycop(char** p);
void myera(char** p);
void mydis(char** p);

int main() {
    pid_t pid;
    char *rt;
    char buf[MAXSIZE];
    int status;
    char *args[64];
    int argnum = 0;

    while (1)
    {
        printf(" %% ");
        rt = fgets(buf,MAXSIZE,stdin);
        if(rt == NULL)
        {
            printf("fgets error");
            exit(0);
        }
        if(strcmp(buf,"\n")==0)
        {
            //printf("\n");
            //printf(" %% ");
            continue;
        }
        if(buf[strlen(buf)-1] == '\n')
            buf[strlen(buf)-1] = 0;
        argnum = parse(buf,args);
        if((strcmp(args[0],"end")==0))
        {
            printf("bey-bey\n");
            exit(0);
        }

        else
        {
            if((pid = vfork())<0)
            {
                printf("vfork error\n");
                continue;
            } else if(pid==0)
            {
                //execvp(*args,args);
                //printf("disable execute\n");
                if (strcmp("dir",args[0])==0)
                    mydir(args);
                else if (strcmp("cop",args[0])==0)
                    mycop(args);
                else if (strcmp("era",args[0])==0)
                    myera(args);
                else if (strcmp("dis",args[0])==0)
                    mydis((args));
            }
            if((pid == waitpid(pid,&status,0))<0)
                printf("waitpid error\n");
        }
    }
    exit(0);

}

// commad analysis by sujianmin
int parse (char *buf, char**args)
{
    int num = 0;
    while (*buf!='\0')
    {
        while ((*buf == ' ')||(*buf == '\t')||(*buf == '\n'))
            *buf++ = '\0';
        *args++ = buf;
        ++num;
        while ((*buf!='\0')&&(*buf!=' ')&&(*buf != '\t')&&(*buf != '\n'))
            buf++;
    }
    *args = '\0';
    return num;
}

//"dir" command by sujianmin
void mydir(char** p)
{
    strcpy(p[0],"ls");
    execvp(*p,p);
}


//"cop" command by sujianmin
void mycop(char** p)
{
    strcpy(p[0],"cp");
    execvp(*p,p);
}

//"era" command by sujianmin
void myera(char** p)
{
    strcpy(p[0],"rm");
    execvp(*p,p);
}

//"dis" command by sujianmin
void mydis(char** p)
{
    printf("%s\n",p[1]);
    exit(0);
}
